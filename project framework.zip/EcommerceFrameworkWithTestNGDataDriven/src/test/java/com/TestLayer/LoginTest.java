package com.TestLayer;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.PageLayer.LoginPage;
import com.UtilLayer.ConfigReader;

public class LoginTest extends BaseTest {
	
	
	
	@Test
	public void testLoginPage() {
		LoginPage lp= new LoginPage(driver);
		lp.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("password"));
		
	}

}
