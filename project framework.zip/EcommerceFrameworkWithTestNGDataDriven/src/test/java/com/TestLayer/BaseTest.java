package com.TestLayer;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.*;

import com.BaseLayer.Base;
import com.UtilLayer.ExtentManager;
import com.UtilLayer.Screenshot;
import com.UtilLayer.WebDriverManager;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class BaseTest extends Base {

	protected static ExtentReports extent;
	protected static ExtentTest test;

	@BeforeSuite
	public void startReport() {
		extent = ExtentManager.getInstance();
	}

	@BeforeClass
	public void initSetup() {
		Base.setUp();
	}

	@BeforeMethod
	public void startTestReport(Method method) {
		test = extent.createTest(method.getName());
	}

	@AfterMethod
	public void tearDownReport(ITestResult result) {
		String status = (result.getStatus() == ITestResult.FAILURE) ? "Failed" : "Passes";
		String screensshotPath = Screenshot.takeScreenshot(driver, result.getName(), status);
		test.addScreenCaptureFromPath(screensshotPath, status + "Screenshot");
	}

	@AfterClass
	public void quitBrowser() {
		Base.tearDown();
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
