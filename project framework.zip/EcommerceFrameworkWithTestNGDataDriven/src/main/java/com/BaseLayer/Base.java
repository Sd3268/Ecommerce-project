package com.BaseLayer;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

import com.UtilLayer.ConfigReader;
import com.UtilLayer.WebDriverManager;

public class Base {
	
	protected static WebDriver driver;
	
	public static void setUp()
	{
		driver=WebDriverManager.getDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get(ConfigReader.getProperty("url"));
	}
	
	
	
	public static void tearDown()
	{
		WebDriverManager.quitDriver();
	}

}
