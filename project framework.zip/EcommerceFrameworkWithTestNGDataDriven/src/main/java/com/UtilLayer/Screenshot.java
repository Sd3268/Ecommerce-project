package com.UtilLayer;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	
	public static String takeScreenshot(WebDriver driver, String testname, String status)
	{
		String timeStamp=new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		String directory=System.getProperty("user.dir")+"/test-output/screenshot/"+status;
		new File(directory).mkdirs();
		String path= directory+"/"+testname+"_"+timeStamp+".png";
			
		File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(srcFile, new File(path));
		} catch(IOException e){
			e.printStackTrace();
		}
		return path;
	}
}
